Razvojna verzija Tin Josip Sokol - Portfolio stranice
Stranica je napravljena u jezicima PHP, JS, HTML, CSS i SQL
Od vanjskih biblioteka jedino je korištena font awesome biblioteka
Potreban je apache server za pokretanje ove verzije web aplikacije i baza podataka sa placeholder slikama
