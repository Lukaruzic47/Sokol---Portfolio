<footer>
	<link rel="stylesheet" href="../css/footer.css" />
	<script src="https://kit.fontawesome.com/f31be06999.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@200&display=swap" rel="stylesheet" />
		<nav>
			<ul class="footer logo">
				<a href="../index.php">TIN JOSIP SOKOL</a>
			</ul>
		</nav>
		<nav class="footer kmetovi">
			<ul class="kmet">
				<a href="../index.php">WELCOME</a>
			</ul>
			<div class="dropdown">
				<ul class="kmet">
					<a id="portfolio">PORTFOLIO </a>
					<div class="dropdown-content">
						<li><a href="../colorGallery.php">MAIN GALLERY</a></li>
						<li><a href="../blackWhiteGallery.php">BLACK & WHITE GALLERY</a></li>
						<li><a href="../coverArts.php">COVER ARTS</a></li>
						<li><a href="../videoGallery.php">MUSIC SPOTS</a></li>
					</div>
				</ul>
			</div>
			<ul class="kmet">
				<a href="../index.php#about-me-section">ABOUT ME</a>
			</ul>
			<!-- <ul class="kmet">
				<a href="">CONTACT ME</a>
			</ul> -->
		</nav>
		<div class="social">
			<a href="https://www.instagram.com/sokifilm/"><i class="fa-brands fa-instagram"></i></a>
			<a href="https://www.tiktok.com/@sokifilm?_t=8iB1Kh0XRho&_r=1"><i class="fa-brands fa-tiktok"></i></a>
			<a href="https://www.youtube.com/@sokifilm"><i class="fa-brands fa-youtube"></i></a>
		</div>
		<div class="copyright">
			<p>&copy; <?php echo Date('Y') ?> TIN JOSIP SOKOL | All rights reserved</p>
		</div>
	</footer>