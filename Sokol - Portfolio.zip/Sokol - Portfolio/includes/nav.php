<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@200&display=swap" rel="stylesheet" />
<link href="../css/fontawesome-free-6.6.0-web/css/all.css" rel="stylesheet" />
<script src="https://kit.fontawesome.com/f31be06999.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="../css/nav.css" />
<div class="nav-placeholder"></div>
<div class="nav-top" id="nav-top">
	<section class="navigation-include index-navigation-include">
		<nav>
			<ul class="logo">
				<a href="index.php">TIN JOSIP SOKOL</a>
			</ul>
		</nav>
		<nav class="kmetovi">
			<ul class="kmet">
				<a href="index.php">WELCOME</a>
			</ul>
			<div class="dropdown">
				<ul class="kmet">
					<a id="portfolio">PORTFOLIO
						<i id="arrow" class="fas fa-caret-down" style="transform: rotate(0deg);"></i>
					</a>

					<div class="dropdown-content">
						<li><a href="../colorGallery.php">MAIN GALLERY</a></li>
						<li><a href="../blackWhiteGallery.php">BLACK & WHITE GALLERY</a></li>
						<li><a href="../coverArts.php">COVER ARTS</a></li>
						<li><a href="../videoGallery.php">MUSIC SPOTS</a></li>
					</div>
				</ul>
			</div>
			<ul class="kmet">
				<a href="../index.php#about-me-section">ABOUT ME</a>
			</ul>
			<?php
			// provjerava je li korisnicko ime postavljeno i ako nije postavlja ga na null
			if (!isset($_SESSION["status"]) || !isset($_SESSION["korisnicko_ime"])) {
				$_SESSION["status"] = 0;
				$_SESSION["korisnicko_ime"] = null;
			}

			// ako je korisnik prijavljen prikazi logout i ostale opcije
			if (isset($_SESSION['status'])) {
				if ($_SESSION['status'] == 1) {
					echo "<ul class='kmet'>
							<a href='#' id='add-new'>ADD NEW
							<i id='arrow-tri' class='fas fa-caret-down' style='transform: rotate(0deg);'></i>
							</a>
							
							<div class='dropdown-content-add-new'>
								<li><a href='../addImage.php'>ADD IMAGE</a></li>
								<li><a href='../addVideo.php'>ADD VIDEO</a></li>
							</div>
							
							</ul>";
					echo "<ul class='kmet'><a href='includes/logout.php'>LOGOUT</a></ul>";
				}
			}
			?>
			<div class="hamburger-wrapper">
				<div class="hamburger-menu"></div>
				<div id="bitchborgar" class="clickable-area"></div>
			</div>
		</nav><br>
	</section>
	<nav class="nav3">
		<?php
		if (isset($_SESSION['status'])) {
			if ($_SESSION['status'] == 1) {
				echo "<p>Dobrodošli " . $_SESSION['korisnicko_ime'] . "</p>";
			}
		}
		?>

	</nav>
	<hr class="fullWidth" />
</div>

<div class="mobile-navigation">
	<div class="logoikona">
		<ul>
			<a href="../index.php">TIN JOSIP SOKOL</a>
		</ul>
		<ul>
			<span id="x" class="x"></span> 
		</ul>
	</div>
	<div class="elementiNavigacije">
		<ul>
			<a href="index.php">WELCOME</a>
		</ul>
		<ul>
			<li id="portfolio-mobile">
				<a href="#">PORTFOLIO</a>
				<i id="arrow-dva" class="fas fa-caret-down"></i>
			</li>
			<div class="dropdown-mobile">
				<li><a href="../colorGallery.php">MAIN GALLERY</a></li>
				<li><a href="../blackWhiteGallery.php">BLACK & WHITE GALLERY</a></li>
				<li><a href="../coverArts.php">COVER ARTS</a></li>
				<li><a href="../videoGallery.php">MUSIC SPOTS</a></li>
			</div>
		</ul>
		<ul>
			<li>
				<a href="index.php#about-me-section">ABOUT ME</a>
			</li>
		</ul>
		<?php
		if (isset($_SESSION['status'])) {
			if ($_SESSION['status'] == 1) {
				echo "
				<ul>
					<li id='add-new-mobile'>
					<a href='#'>ADD NEW</a>
					<i id='arrow-four' class='fas fa-caret-down'></i>
					</li>
						<div class='dropdown-mobile-add-new'>
							<li><a href='../addImage.php'>ADD IMAGE</a></li>
							<li><a href='../addVideo.php'>ADD VIDEO</a></li>
						</div>
				</ul>";
				echo "<ul><a href='includes/logout.php'>LOGOUT</a></ul>";
				echo "<ul><p class='welcome'>Dobrodošli " . $_SESSION['korisnicko_ime'] . "</p></ul>";
			}
		}
		?>

	</div>
</div>
<?php

if (isset($_SESSION['status'])) {
	if ($_SESSION['status'] == 1) {
		echo "<script src='../js/Navigation.js'></script>";
		echo "<script src='../js/NavigationAdmin.js'></script>";
	} else {
		echo "<script src='../js/Navigation.js'></script>";
	}
}

?>