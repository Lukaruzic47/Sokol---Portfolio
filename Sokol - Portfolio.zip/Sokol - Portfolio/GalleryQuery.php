<?php

// require "includes/autoriziran-pristup.php";

function getImageData($prfx, $res, $xml, $imgData){
    while ($red = $res->fetch_array()) {
        $slika = $xml->createElement("Image");
        $imgData->appendChild($slika);
    
        $SlikaID = $xml->createElement("ID", $red[$prfx . 'Images_ID']);
        $slika->appendChild($SlikaID);
    
        $SlikaNaziv = $xml->createElement("Name", $red[$prfx . '_name']);
        $slika->appendChild($SlikaNaziv);
    
        $SlikaDatum = $xml->createElement("Date", $red[$prfx . '_date']);
        $slika->appendChild($SlikaDatum);
    
        $SlikaPutanja = $xml->createElement("Image_Path", $red[$prfx . '_image']);
        $slika->appendChild($SlikaPutanja);
    
        $SlikaStupacTV = $xml->createElement("TV_Column", $red[$prfx . '_TV_Column']);
        $slika->appendChild($SlikaStupacTV);
    
        $SlikaRbTV = $xml->createElement("TV_Position", $red[$prfx . '_TV_no']);
        $slika->appendChild($SlikaRbTV);
    
        $SlikaStupacDesktop = $xml->createElement("Desktop_Column", $red[$prfx . '_Desktop_Column']);
        $slika->appendChild($SlikaStupacDesktop);
    
        $SlikaRbDesktop = $xml->createElement("Desktop_Position", $red[$prfx . '_Desktop_no']);
        $slika->appendChild($SlikaRbDesktop);
    
        $SlikaStupacTablet = $xml->createElement("Tablet_Column", $red[$prfx . '_Tablet_Column']);
        $slika->appendChild($SlikaStupacTablet);
    
        $SlikaRbTablet = $xml->createElement("Tablet_Position", $red[$prfx . '_Tablet_no']);
        $slika->appendChild($SlikaRbTablet);
    
        $SlikaRbMobitel = $xml->createElement("Mobile_Position", $red[$prfx . '_Mobile_no']);
        $slika->appendChild($SlikaRbMobitel);
    }
}

header('Content-Type: text/xml');

$order = $_POST['orderBy'];
$table = $_POST['source']; 

include "includes/bazafolio.php";
$baza = new Baza();
$upit = "SELECT * FROM $table /* WHERE CImages_ID <= 24*/ ORDER BY $order";

$rezultat = $baza->dohvatiDB($upit);

$xml = new DOMDocument("1.0", 'UTF-8');
$xml->formatOutput = true;

$slikeData = $xml->createElement("All_images");
$xml->appendChild($slikeData);

$prefix = strtoupper(substr($table, 0, 2));

getImageData($prefix, $rezultat, $xml, $slikeData);

echo $xml->saveXML();
?>