if (window.innerWidth <= 1280) {
    gsap.from('.main-header-1', {duration: 0.8, x: -500, opacity: 0, ease: 'ease-in-out'});
    gsap.from('.main-header-2', {duration: 0.7, x: -500, opacity: 0, delay: 0.3, ease: 'ease-in-out'});
    gsap.from('.main-header-3', {duration: 0.6, x: -500, opacity: 0, delay: 0.1, ease: 'ease-in-out'});
}