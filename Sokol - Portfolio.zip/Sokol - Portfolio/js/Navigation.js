var toggleVal1 = 0;
var toggleVal2 = 0;
var toggleVal3 = 0;

if(document.getElementById('portfolio')) {
    document.getElementById('portfolio').addEventListener('click', function() {
      if(toggleVal2) {
        document.querySelector('.dropdown-content-add-new').style.display = 'none';
        document.getElementById('arrow-tri').style.transform = 'rotate(0deg)';
        toggleVal2 = 0;
      }
      var dropdownContent = document.querySelector('.dropdown-content');
      var strelica = document.getElementById('arrow');
    
      toggleVal1 = toggleVal1 === 0 ? 1 : 0;
    
      if(toggleVal1 === 1) {
        document.getElementById('portfolio').style.pointerEvents = 'none';
        setTimeout(function() {
        document.getElementById('portfolio').style.pointerEvents = 'auto';
        }, 300);
    
        strelica.style.transform = 'rotate(-180deg)';
        dropdownContent.style.opacity = '0';
        dropdownContent.style.display = 'block';
        setTimeout(function() {
        dropdownContent.style.opacity = '1';
        }, 10);
      }
    
      if(!toggleVal1) {
        document.getElementById('portfolio').style.pointerEvents = 'none';
        setTimeout(function() {
        document.getElementById('portfolio').style.pointerEvents = 'auto';
        }, 300);
    
        strelica.style.transform = 'rotate(0deg)';
    
        dropdownContent.style.opacity = '0';
        setTimeout(function() {
        dropdownContent.style.display = 'none';
        }, 250);
      }
    });
}

if(document.getElementById('portfolio-mobile')){

  document.getElementById('portfolio-mobile').addEventListener('click', function() {
    var dropdownContentDva = document.querySelector('.dropdown-mobile');
    var strelicaDva = document.getElementById('arrow-dva');
    
    // Promijeni ikonu strelice
    strelicaDva.classList.toggle('fa-caret-down');
    strelicaDva.classList.toggle('fa-caret-up');
    
    // Postavi visinu na nulu ako je strelica prema dolje, inače postavi željenu visinu
    dropdownContentDva.style.height = strelicaDva.classList.contains('fa-caret-up') ? '125px' : '0';
    dropdownContentDva.style.margin = strelicaDva.classList.contains('fa-caret-down') ? '0px 0px 0px 20px' : '10px 0px 0px 20px';
  });
}
  
if(document.getElementById('bitchborgar')){
  document.getElementById('bitchborgar').addEventListener('click', function() {
    document.querySelector('.mobile-navigation').style.display = 'flex';
    document.getElementById('x').addEventListener('click', function(){
      document.querySelector('.mobile-navigation').style.display = 'none';
    });
  });
}
  
  var previousPosition = window.scrollY;

window.onscroll = function() {
  var currentPosition = window.scrollY;

  if (previousPosition > currentPosition) {
    if(document.getElementById("nav-top")){
      document.getElementById("nav-top").style.top = "0";
    }
  } else {
    if(document.getElementById("nav-top")){
      document.getElementById("nav-top").style.top = "-121px";
    }
  }

  previousPosition = currentPosition;
};






