var currentWindowSize = window.innerWidth;
var currentColNumber;
var getDataFrom = "";

function getValueLol(value1) {
    getDataFrom = value1;
}

function checkOnResize() {
    currentWindowSize = window.innerWidth;
	if (currentColNumber != 2 && currentWindowSize > 650) {
		columnGeneration(2);
	}
	if (currentColNumber != 1 && currentWindowSize <= 650) {
		columnGeneration(1);
	}
}

function columnGeneration(columns) {
    currentColNumber = columns;
    var stupac = "";
    for (let i = 1; i <= columns; i++) {
        stupac += "<div class='videoColumns videoColumn" + i + "' id='stupac" + i + "'></div>"
    }
    document.getElementById("videoGalerija").innerHTML = stupac;
    videoDisplay(columns, getDataFrom);
}

function videoDisplay(columns, table) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var PageContentColumn01 = "", PageContentColumn02 = "";
            var VideoID, VideoNaziv, VideoLink, VideoDesc, toggler = 1;
            var xml = xhttp.responseXML;
            var album = xml.getElementsByTagName("Video");
            for (let i = 0; i < album.length; i++) {
                VideoID = album[i].getElementsByTagName("ID")[0].innerHTML;
                VideoNaziv = album[i].getElementsByTagName("Name")[0].innerHTML;
                VideoLink = album[i].getElementsByTagName("Link")[0].innerHTML;
                VideoDesc = album[i].getElementsByTagName("Desc")[0].innerHTML;

                const container = document.createElement('div');
                const video_container = document.createElement('div');
                video_container.classList.add('video-container');
                container.appendChild(video_container);

                const iframe_parent = document.createElement('div');
                iframe_parent.classList.add('iframe-parent');
                video_container.appendChild(iframe_parent);

                const iframe = document.createElement('iframe');
                iframe.src = VideoLink;
                iframe.alt = VideoNaziv;
                iframe.classList.add('video-iframe');
                iframe.setAttribute('allow', 'picture-in-picture; fullscreen');
                iframe.setAttribute('allowfullscreen', '');
                iframe_parent.appendChild(iframe);
				
                const header = document.createElement('h3');
                header.innerText = VideoNaziv;
                header.classList.add('video-header');
                video_container.appendChild(header);

                const description = document.createElement('p');
                description.innerText = VideoDesc;
                description.classList.add('video-description');
                video_container.appendChild(description);

				if(columns == 1){
					PageContentColumn01 += container.outerHTML;
				}
                else if (columns !== 1 && toggler === 1) {
                    PageContentColumn01 += container.outerHTML;
                    toggler = 2;
                } 
				else if(columns !== 1 && toggler === 2) {
                    PageContentColumn02 += container.outerHTML;
                    toggler = 1;
                }
            }

            document.getElementById("stupac1").innerHTML = PageContentColumn01;
            document.getElementById("stupac2").innerHTML = PageContentColumn02;
        }
    };
    var postContent = "source=" + encodeURIComponent(table) + "&orderBy=Spot_ID";
    xhttp.open("POST", "videoGalleryQuery.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send(postContent);
}

document.addEventListener("DOMContentLoaded", checkOnResize);
window.addEventListener("resize", checkOnResize);