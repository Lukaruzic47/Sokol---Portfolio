const backgroundImageBlur = document.querySelector('.main-page-background');
const viewportHeight = window.innerHeight;

window.addEventListener('scroll', () => {
    let scrollTop = window.scrollY || document.documentElement.scrollTop;
    
    let blurValue = Math.min((scrollTop / viewportHeight) * 15, 15); 
    let opacityValue = Math.min((scrollTop / viewportHeight) * 0.6, 0.6);

    backgroundImageBlur.style.filter = `blur(${blurValue}px)`;
    backgroundImageBlur.style.opacity = 1 - opacityValue;
});
