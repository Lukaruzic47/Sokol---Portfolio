var toggleVal1 = 0;
var toggleVal2 = 0;
var toggleVal3 = 0;

document.getElementById('add-new').addEventListener('click', function() {
  if(toggleVal1) {
    document.querySelector('.dropdown-content').style.display = 'none';
    document.getElementById('arrow').style.transform = 'rotate(0deg)';
    toggleVal1 = 0;
  }
  var dropdownContent = document.querySelector('.dropdown-content-add-new');
  var strelica = document.getElementById('arrow-tri');

  toggleVal2 = toggleVal2 === 0 ? 1 : 0;

  if(toggleVal2 === 1) {
    document.getElementById('add-new').style.pointerEvents = 'none';
    setTimeout(function() {
    document.getElementById('add-new').style.pointerEvents = 'auto';
    }, 300);

    strelica.style.transform = 'rotate(-180deg)';
    dropdownContent.style.opacity = '0';
    dropdownContent.style.display = 'block';
    setTimeout(function() {
    dropdownContent.style.opacity = '1';
    }, 10);
  }

  if(!toggleVal2) {
    document.getElementById('add-new').style.pointerEvents = 'none';
    setTimeout(function() {
    document.getElementById('add-new').style.pointerEvents = 'auto';
    }, 300);

    strelica.style.transform = 'rotate(0deg)';

    dropdownContent.style.opacity = '0';
    setTimeout(function() {
    dropdownContent.style.display = 'none';
    }, 250);
  }

});

document.getElementById('add-new-mobile').addEventListener('click', function() {
    var dropdownContentTri = document.querySelector('.dropdown-mobile-add-new');
    var strelicaTri = document.getElementById('arrow-four');

    // Promijeni ikonu strelice
    strelicaTri.classList.toggle('fa-caret-down');
    strelicaTri.classList.toggle('fa-caret-up');

    // Postavi visinu na nulu ako je strelica prema dolje, inače postavi željenu visinu
    dropdownContentTri.style.height = strelicaTri.classList.contains('fa-caret-up') ? '70px' : '0';
    dropdownContentTri.style.margin = strelicaTri.classList.contains('fa-caret-down') ? '0px 0px 0px 20px' : '10px 0px 0px 20px';
});


