<?php
    function convertToTitle($columnNumber) {
        $return = '';

        while($columnNumber > 0){
            $columnNumber--;
            $return .= chr($columnNumber % 26 + 65);
            $columnNumber = intval($columnNumber / 26);
        }

        $return = strrev($return);
        return $return;
    }
    echo "radi <br>";
    echo convertToTitle(703);
?>