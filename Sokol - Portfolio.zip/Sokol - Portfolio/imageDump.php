<html>
<body>
<h1>Image dump</h1>
<form action="" method="post">
    <select name="type">
        <option value="Color">Color</option>
        <option value="BW">Black - white</option>
        <option value="CA">Cover arts</option>
    </select>
    <button type="submit" name="submit">Uploadaj sve slike</button>
</form>
<?php
require 'includes/bazafolio.php';
if (isset($_POST['submit'])) {
    echo '<p>Pokrenuta skripta</p></br>';
    if ($_POST['type'] == 'Color') {
        $img_dir_path = __DIR__ . '/images/Color/';
        $table = 'cimages';
        $prefix = 'CI';
    } else if ($_POST['type'] == 'BW') {
        $img_dir_path = __DIR__ . '/images/BlackWhite/';
        $table = 'bwimages';
        $prefix = 'BW';
    } else if ($_POST['type'] == 'CA') {
        $img_dir_path = __DIR__ . '/images/CoverArts/';
        $table = 'caimages';
        $prefix = 'CA';
    } else {
        $img_dir_path = __DIR__ . '/images/Color/';
        echo "tražim slike u {$img_dir_path}</br>";
    }

    $database = new Baza();
    $images = [];
    $images = scandir($img_dir_path);
    echo 'Dohvaćeno ' . count($images) . ' slika</br>';
    $counter = 0;
    shuffle($images);
    $query = "INSERT INTO `$table` (`{$prefix}Images_ID`, `{$prefix}_name`, `{$prefix}_date`, `{$prefix}_image`, `{$prefix}_TV_Column`, `{$prefix}_TV_no`, `{$prefix}_Desktop_Column`, `{$prefix}_Desktop_no`, `{$prefix}_Tablet_Column`, `{$prefix}_Tablet_no`, `{$prefix}_Mobile_no`) VALUES \n";
        foreach ($images as $image) {
            if ($image == '.' || $image == '..') {
                continue;
            }
            $name = $image;
            $date = $date = date('Y-m-d', rand(strtotime('2022-01-01'), time()));
            $image_path = $image;
            $TV_Column = ($counter % 4) + 1;
            $TV_no = floor($counter / 4) + 1;
            $Desktop_Column = ($counter % 3) + 1;
            $Desktop_no = floor($counter / 3) + 1;
            $Tablet_Column = ($counter % 2) + 1;
            $Tablet_no = floor($counter / 2) + 1;
            $Mobile_no = $counter + 1;
            $counter++;

            $query .= "($counter, '$name', '$date', '$image_path', $TV_Column, $TV_no, $Desktop_Column, $Desktop_no, $Tablet_Column, $Tablet_no, $Mobile_no), \n";
        }

    $query = rtrim($query, ", \n");
    $deleteQuery = "DELETE FROM `$table`";
    echo '<pre>';
    print_r($query);
    echo '</pre>';
    $database->promijeniDB($deleteQuery);
    $database->promijeniDB($query);
}
?>
</body>
</html>