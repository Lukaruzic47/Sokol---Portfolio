<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Tin Josip Sokol, Photography, Portfolio, Photographer, Videographer, Art, Gallery">
    <meta name="description" content="Tin Josip Sokol - A dedicated photographer capturing moments, memories, and the essence of every moment. Explore my portfolio and discover my work.">
    <meta name="author" content="Tin Josip Sokol">
    <title>Tin Josip Sokol - Portfolio</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200&display=swap" rel="stylesheet" />
    <link href="css/fontawesome-free-6.6.0-web/css/all.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/f31be06999.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>

    <?php
        session_start();
    ?>
    <script src='../js/Navigation.js'></script>
    <script defer src="js/index-animations.js"></script>
</head>

<body>
    <section class="navigation-include index-navigation-include">
        <nav class="kmetovi">
            <ul class="kmet first-down">
                <a href="index.php">WELCOME</a>
            </ul>
            <div class="dropdown second-down">
                <ul class="kmet">
                    <a id="portfolio">PORTFOLIO
                        <i id="arrow" class="fas fa-caret-down" style="transform: rotate(0deg);"></i>
                    </a>

                    <div class="dropdown-content">
                        <li><a href="../colorGallery.php">MAIN GALLERY</a></li>
                        <li><a href="../blackWhiteGallery.php">BLACK & WHITE GALLERY</a></li>
                        <li><a href="../coverArts.php">COVER ARTS</a></li>
                        <li><a href="../videoGallery.php">MUSIC SPOTS</a></li>
                    </div>
                </ul>
            </div>
            <ul class="kmet third-down">
                <a href="../index.php#about-me-section">ABOUT ME</a>
            </ul>
            <?php
            // provjerava je li korisnicko ime postavljeno i ako nije postavlja ga na null
            if (!isset($_SESSION["status"]) || !isset($_SESSION["korisnicko_ime"])) {
                $_SESSION["status"] = 0;
                $_SESSION["korisnicko_ime"] = null;
            }

            // ako je korisnik prijavljen prikazi logout i ostale opcije
            if (isset($_SESSION['status'])) {
                if ($_SESSION['status'] == 1) {
                    echo "<ul class='kmet fourth-down'>
							<a href='#' id='add-new'>ADD NEW
							<i id='arrow-tri' class='fas fa-caret-down' style='transform: rotate(0deg);'></i>
							</a>
							
							<div class='dropdown-content-add-new'>
								<li><a href='../addImage.php'>ADD IMAGE</a></li>
								<li><a href='../addVideo.php'>ADD VIDEO</a></li>
							</div>
							
							</ul>";
                    echo "<ul class='kmet fifth-down'><a href='includes/logout.php'>LOGOUT</a></ul>";
                }
            }
            ?>
            <div class="hamburger-wrapper">
                <div class="hamburger-menu"></div>
                <div id="bitchborgar" class="clickable-area"></div>
            </div>
        </nav><br>
    </section>
    <nav class="nav3">
        <?php
        if (isset($_SESSION['status'])) {
            if ($_SESSION['status'] == 1) {
                echo "<p>Dobrodošli " . $_SESSION['korisnicko_ime'] . "</p>";
            }
        }
        ?>

    </nav>
    <div class="mobile-navigation">
        <div class="logoikona">
            <ul>
                <a href="../index.php">TIN JOSIP SOKOL</a>
            </ul>
            <ul>
                <span id="x" class="x"></span>
            </ul>
        </div>
        <div class="elementiNavigacije">
            <ul>
                <a href="index.php">WELCOME</a>
            </ul>
            <ul>
                <li id="portfolio-mobile">
                    <a href="#">PORTFOLIO</a>
                    <i id="arrow-dva" class="fas fa-caret-down"></i>
                </li>
                <div class="dropdown-mobile">
                    <li><a href="../colorGallery.php">MAIN GALLERY</a></li>
                    <li><a href="../blackWhiteGallery.php">BLACK & WHITE GALLERY</a></li>
                    <li><a href="../coverArts.php">COVER ARTS</a></li>
                    <li><a href="../videoGallery.php">MUSIC SPOTS</a></li>
                </div>
            </ul>
            <ul>
                <li>
                    <a href="index.php#about-me-section">ABOUT ME</a>
                </li>
            </ul>
            <?php
            if (isset($_SESSION['status'])) {
                if ($_SESSION['status'] == 1) {
                    echo "
				<ul>
					<li id='add-new-mobile'>
					<a href='#'>ADD NEW</a>
					<i id='arrow-four' class='fas fa-caret-down'></i>
					</li>
						<div class='dropdown-mobile-add-new'>
							<li><a href='../addImage.php'>ADD IMAGE</a></li>
							<li><a href='../addVideo.php'>ADD VIDEO</a></li>
						</div>
				</ul>";
                    echo "<ul><a href='includes/logout.php'>LOGOUT</a></ul>";
                    echo "<ul><p class='welcome'>Dobrodošli " . $_SESSION['korisnicko_ime'] . "</p></ul>";
                }
            }

            if (isset($_SESSION['status'])) {
                if ($_SESSION['status'] == 1) {
                    echo "<script src='../js/NavigationAdmin.js'></script>";
                }
            }
            ?>

        </div>
    </div>
    <div class="main-page-background">

    </div>
    <!-- <img class="main-page-background" src="images/Images/website_photo_2.webp" alt=""> -->
    <div class="content"></div>
    <div class="gradient"></div>
    <section class="welcome-content">

        <div class="hero-content">
            <h4>Welcome to</h4>
            <div class="main-header">
                <div class="main-header-1">
                    <h1>TIN</h1>
                </div>
                <div class="main-header-2">
                    <h1>JOSIP SOKOL</h1>
                </div><br>
                <div class="main-header-3">
                    <h1>PHOTOGRAPHY</h1>
                </div>
            </div>
            <h5>My name is Tin Josip Sokol, I’m a dedicated photographer with the purpose of capturing moments, memories and the essence of every moment</h5>
            <div class="button-container">
                <a href="#about-me-section"><button class="about-me-btn">ABOUT ME</button></a>
                <a href="colorGallery.php">
                    <button class="my-work-btn">MY WORK</button>
                </a>
            </div>
        </div>
        <a href="#about-me-section">
            <svg class="arrows">
                <path class="a1" d="M0 0 L30 32 L60 0"></path>
                <path class="a2" d="M0 20 L30 52 L60 20"></path>
                <path class="a3" d="M0 40 L30 72 L60 40"></path>
            </svg>
        </a>
    </section>

    <section class="about-me-section" id="about-me-section">
        <div class="about-me-wrapper">
            <h2>TIN JOSIP SOKOL</h2>
            <span class="roles">photographer / videographer</span>
            <p class="about-me-desc">
                My name is Tin Josip Sokol, I’m a dedicated photographer with the purpose of capturing moments, memories and the essence of every moment. I’m a passionate photographer with a love for capturing the beauty of the world around me. <br><br> I have a keen eye for detail and a love for the art of photography. I’m always looking for new ways to capture the world around me and I’m always looking for new ways to improve my skills. I’m a dedicated photographer with a passion for capturing the beauty of the world around me. <br><br> I’m always looking for new ways to improve my skills and I’m always looking for new ways to capture the world around me.
            </p>
            <div class="about-me-image">
                <img src="images\Images\website photo.png" alt="">
            </div>
        </div>
    </section>
    <script src="js/Navigation.js"></script>
    <script src="js/index.js"></script>
</body>

</html>