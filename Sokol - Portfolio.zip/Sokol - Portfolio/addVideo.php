<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add new image</title>
    <?php
    session_start();

    $_SESSION['podatci'] = array('title' => 'NEW VIDEO', 'breadcrumbs' => 'Admin / Add New');
    ?>
    <link rel="stylesheet" href="css/addImage.css">
    <link rel="stylesheet" href="css/addEditSave.css">
</head>

<body>
    <?php
    require "includes/autoriziran-pristup.php";
    require_once "includes/bazafolio.php";
    include "includes/nav.php";
    include "includes/title.php";

    if(isset($_POST['submit'])){
        $baza = new Baza();
        
        $naziv_videa = $baza->escapeInput(trim(strip_tags($_POST['naziv_videa'])));
        $link_videa = $baza->escapeInput(trim(strip_tags($_POST['link_videa'])));
        $opis_videa = $baza->escapeInput(trim(strip_tags($_POST['opis_videa'])));

        $upit = "INSERT INTO musicspots (Spot_name, Spot_link, Spot_desc) VALUES ('$naziv_videa', '$link_videa', '$opis_videa')";
        $baza->dohvatiDB($upit);
        echo "
        <main class='AESave'>
            <div class='AEScontainer'>
            <p class='AESresult'>Video uspješno dodan</p>
            <div class='' id='klasa'><iframe src=" . $link_videa . " class='AESiframe alt=''></iframe>
            <div>
                <a class='AESa' href='addVideo.php'><button class='AESbutton'>ADD NEW</button></a>
                <a class='AESa' href='videoGallery.php'><button class='AESbutton'>RETURN</button></a>
            </div>
            </div>
        </main>
        ";
    }
    else{
        echo "
        
        <main id='dodaj'>
        <form class='addImage' action='addVideo.php' enctype='multipart/form-data' method='post'>
            <div class='form1'>
                <div class='inputElement1'>
                    <label for='naziv'>Naslov videa</label><br>
                    <input type='text' name='naziv_videa' id='naziv_videa' class='form1-input' required>
                </div>
                <div class='inputElement1'>
                    <label for='date'>Youtube link</label><br>
                    <input type='text' name='link_videa' id='link_videa' class='form1-input' required>
                </div>
            </div>
            <div class='form3'>
                <div class='inputElement5'>
                    <label for='opis_videa'>Opis videa</label><br>
                    <textarea name='opis_videa' id='opis_videa' class='form1-input'></textarea>
                </div>
            </div>
            <div class='form4'>
                <div class='inputElement6'>
                    <button class='submit' name='submit' type='submit'>SUBMIT</button>
                </div>
            </div>
            </form> 
            </main>";
    }
    ?>
    <?php include "includes/footer.php" ?>
    <script src="js/test.js"></script>
</body>

</html>